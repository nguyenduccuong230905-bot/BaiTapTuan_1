﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using QuanLySinhVien.models;

namespace QuanLySinhVien
{
    public partial class FrmQuanLySinhVien : Form
    {
        Model1 context = new Model1();
        public FrmQuanLySinhVien()
        {
            InitializeComponent();
        }

        private void FrmQuanLySinhVien_Load(object sender, EventArgs e)
        {
            LoadFaculty();
            LoadStudent();
        }

        private void LoadFaculty()
        {
            cmbKhoa.DataSource = context.Faculties.ToList();
            cmbKhoa.DisplayMember = "FacultyName";
            cmbKhoa.ValueMember = "FacultyID";
        }

        private void LoadStudent()
        {
            dgvSinhVien.Rows.Clear();
            var list = context.Students.ToList();

            foreach (var s in list)
            {
                int i = dgvSinhVien.Rows.Add();
                dgvSinhVien.Rows[i].Cells[0].Value = s.StudentID;
                dgvSinhVien.Rows[i].Cells[1].Value = s.FullName;
                dgvSinhVien.Rows[i].Cells[2].Value = s.Faculty.FacultyName;
                dgvSinhVien.Rows[i].Cells[3].Value = s.AverageScore;
            }
        }

        private bool CheckInput()
        {
            if (txtMSSV.Text == "" || txtHoTen.Text == "" || txtDiemTB.Text == "")
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin!");
                return false;
            }

            if (txtMSSV.Text.Length != 10)
            {
                MessageBox.Show("Mã số sinh viên phải có 10 kí tự!");
                return false;
            }

            if (!double.TryParse(txtDiemTB.Text, out _))
            {
                MessageBox.Show("Điểm trung bình không hợp lệ!");
                return false;
            }

            return true;
        }

        private void ResetForm()
        {
            txtMSSV.Clear();
            txtHoTen.Clear();
            txtDiemTB.Clear();
            cmbKhoa.SelectedIndex = 0;
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            if (!CheckInput()) return;

            var sv = context.Students.FirstOrDefault(x => x.StudentID == txtMSSV.Text);
            if (sv != null)
            {
                MessageBox.Show("MSSV đã tồn tại!");
                return;
            }

            Student s = new Student
            {
                StudentID = txtMSSV.Text,
                FullName = txtHoTen.Text,
                AverageScore = double.Parse(txtDiemTB.Text),
                FacultyID = (int)cmbKhoa.SelectedValue
            };

            context.Students.Add(s);
            context.SaveChanges();
            LoadStudent();
            ResetForm();

            MessageBox.Show("Thêm mới dữ liệu thành công!");
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            if (!CheckInput()) return;

            var sv = context.Students.FirstOrDefault(x => x.StudentID == txtMSSV.Text);
            if (sv == null)
            {
                MessageBox.Show("Không tìm thấy MSSV cần sửa!");
                return;
            }

            sv.FullName = txtHoTen.Text;
            sv.AverageScore = double.Parse(txtDiemTB.Text);
            sv.FacultyID = (int)cmbKhoa.SelectedValue;

            context.SaveChanges();
            LoadStudent();
            ResetForm();

            MessageBox.Show("Cập nhật dữ liệu thành công!");
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            var sv = context.Students.FirstOrDefault(x => x.StudentID == txtMSSV.Text);
            if (sv == null)
            {
                MessageBox.Show("Không tìm thấy MSSV cần xóa!");
                return;
            }

            if (MessageBox.Show("Bạn có chắc muốn xóa?", "Xác nhận",
                MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                context.Students.Remove(sv);
                context.SaveChanges();
                LoadStudent();
                ResetForm();
                MessageBox.Show("Xóa sinh viên thành công!");
            }
        }

        private void dgvSinhVien_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                txtMSSV.Text = dgvSinhVien.Rows[e.RowIndex].Cells[0].Value.ToString();
                txtHoTen.Text = dgvSinhVien.Rows[e.RowIndex].Cells[1].Value.ToString();
                txtDiemTB.Text = dgvSinhVien.Rows[e.RowIndex].Cells[3].Value.ToString();
                cmbKhoa.Text = dgvSinhVien.Rows[e.RowIndex].Cells[2].Value.ToString();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
