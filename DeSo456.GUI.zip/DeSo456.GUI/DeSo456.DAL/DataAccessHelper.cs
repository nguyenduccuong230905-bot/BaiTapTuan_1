﻿using System;
using System.Reflection;

namespace DeSo456.DAL
{
    public class DataAccessHelper
    {
        public static string GetConnectionString()
        {
            const string defaultConn = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=DeSo456;Integrated Security=True;";

            try
            {
                // Use reflection to avoid a hard compile-time dependency on System.Configuration.
                // If the assembly is referenced, this will read the named connection string.
                var cmType = Type.GetType("System.Configuration.ConfigurationManager, System.Configuration");
                if (cmType != null)
                {
                    var connStringsProp = cmType.GetProperty("ConnectionStrings", BindingFlags.Static | BindingFlags.Public);
                    var connStrings = connStringsProp?.GetValue(null);
                    if (connStrings != null)
                    {
                        // ConnectionStringSettingsCollection has an indexer 'Item[string name]'
                        var itemProp = connStrings.GetType().GetProperty("Item", new[] { typeof(string) });
                        var csSetting = itemProp?.GetValue(connStrings, new object[] { "DeSo456" });
                        if (csSetting != null)
                        {
                            var csProp = csSetting.GetType().GetProperty("ConnectionString", BindingFlags.Public | BindingFlags.Instance);
                            var csValue = csProp?.GetValue(csSetting) as string;
                            if (!string.IsNullOrWhiteSpace(csValue)) return csValue;
                        }
                    }
                }
            }
            catch
            {
                // ignore and fall back to default
            }

            return defaultConn;
        }
    }
}