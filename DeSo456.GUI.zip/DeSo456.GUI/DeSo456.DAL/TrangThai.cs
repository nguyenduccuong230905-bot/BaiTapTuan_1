namespace DeSo456.DAL
{
    public class TrangThai
    {
        public int MaTT { get; set; }
        public string TenTT { get; set; }
        public string GhiChu { get; set; }
    }
}