﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeSo456.DAL
{
    public class TrangThaiDAL
    {
        public List<TrangThai> GetAll()
        {
            var list = new List<TrangThai>();
            string sql = "SELECT MaTT, TenTT, GhiChu FROM TrangThai";
            using (var conn = new SqlConnection(DataAccessHelper.GetConnectionString()))
            {
                conn.Open();
                using (var cmd = new SqlCommand(sql, conn))
                using (var reader = cmd.ExecuteReader())
                {
                    // get ordinals once
                    int idxMaTT = reader.GetOrdinal("MaTT");
                    int idxTenTT = reader.GetOrdinal("TenTT");
                    int idxGhiChu = reader.GetOrdinal("GhiChu");

                    while (reader.Read())
                    {
                        list.Add(new TrangThai
                        {
                            MaTT = reader.IsDBNull(idxMaTT) ? 0 : reader.GetInt32(idxMaTT),
                            TenTT = reader.IsDBNull(idxTenTT) ? null : reader.GetString(idxTenTT),
                            GhiChu = reader.IsDBNull(idxGhiChu) ? null : reader.GetString(idxGhiChu)
                        });
                    }
                }
            }
            return list;
        }
    }
}