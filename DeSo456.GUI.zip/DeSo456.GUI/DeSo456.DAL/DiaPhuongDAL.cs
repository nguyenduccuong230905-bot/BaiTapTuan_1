﻿using System;
using System.Collections.Generic;
using System.Data;
        using System.Data.SqlClient;
using DeSo456.GUI;

namespace DeSo456.DAL
{
    public class DiaPhuongDAL
    {
        private readonly string _connectionString;

        public DiaPhuongDAL(string connectionString = null)
        {
            _connectionString = string.IsNullOrWhiteSpace(connectionString)
                ? DataAccessHelper.GetConnectionString()
                : connectionString;
        }

        public List<DiaPhuong> GetAll()
        {
            const string sql = @"
                SELECT dp.MaDP, dp.TenDP, dp.SoCaNhiemMoi, dp.MaTT, tt.TenTT
                FROM DiaPhuong dp
                INNER JOIN TrangThai tt ON dp.MaTT = tt.MaTT";

            using (var conn = new SqlConnection(_connectionString))
            using (var cmd = new SqlCommand(sql, conn))
            {
                return ExecuteList(cmd);
            }
        }

        public bool Insert(DiaPhuong dp)
        {
            const string sql = "INSERT INTO DiaPhuong (MaDP, TenDP, SoCaNhiemMoi, MaTT) VALUES (@MaDP, @TenDP, @SoCaNhiemMoi, @MaTT)";

            using (var conn = new SqlConnection(_connectionString))
            using (var cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.AddWithValue("@MaDP", (object)dp.MaDP ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@TenDP", (object)dp.TenDP ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@SoCaNhiemMoi", dp.SoCaNhiemMoi);
                cmd.Parameters.AddWithValue("@MaTT", dp.MaTT);

                conn.Open();
                return cmd.ExecuteNonQuery() > 0;
            }
        }

        public bool Update(DiaPhuong dp)
        {
            const string sql = "UPDATE DiaPhuong SET TenDP = @TenDP, SoCaNhiemMoi = @SoCaNhiemMoi, MaTT = @MaTT WHERE MaDP = @MaDP";

            using (var conn = new SqlConnection(_connectionString))
            using (var cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.AddWithValue("@MaDP", (object)dp.MaDP ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@TenDP", (object)dp.TenDP ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@SoCaNhiemMoi", dp.SoCaNhiemMoi);
                cmd.Parameters.AddWithValue("@MaTT", dp.MaTT);

                conn.Open();
                return cmd.ExecuteNonQuery() > 0;
            }
        }

        public DiaPhuong GetByMaDP(string maDP)
        {
            const string sql = @"
                SELECT dp.MaDP, dp.TenDP, dp.SoCaNhiemMoi, dp.MaTT, tt.TenTT
                FROM DiaPhuong dp
                INNER JOIN TrangThai tt ON dp.MaTT = tt.MaTT
                WHERE dp.MaDP = @MaDP";

            using (var conn = new SqlConnection(_connectionString))
            using (var cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.AddWithValue("@MaDP", (object)maDP ?? DBNull.Value);

                conn.Open();
                using (var reader = cmd.ExecuteReader())
                {
                    if (!reader.Read()) return null;
                    return Map(reader);
                }
            }
        }

        public List<DiaPhuong> GetNguyCo()
        {
            const string sql = @"
                SELECT dp.MaDP, dp.TenDP, dp.SoCaNhiemMoi, dp.MaTT, tt.TenTT
                FROM DiaPhuong dp
                INNER JOIN TrangThai tt ON dp.MaTT = tt.MaTT
                WHERE tt.TenTT != N'Bình thường'";

            using (var conn = new SqlConnection(_connectionString))
            using (var cmd = new SqlCommand(sql, conn))
            {
                return ExecuteList(cmd);
            }
        }

        public List<DiaPhuong> GetAllSorted(bool ascending = false)
        {
            var order = ascending ? "ASC" : "DESC";
            var sql = $@"
                SELECT dp.MaDP, dp.TenDP, dp.SoCaNhiemMoi, dp.MaTT, tt.TenTT
                FROM DiaPhuong dp
                INNER JOIN TrangThai tt ON dp.MaTT = tt.MaTT
                ORDER BY dp.SoCaNhiemMoi {order}";

            using (var conn = new SqlConnection(_connectionString))
            using (var cmd = new SqlCommand(sql, conn))
            {
                return ExecuteList(cmd);
            }
        }

        // --- Helpers ---

        private List<DiaPhuong> ExecuteList(SqlCommand cmd)
        {
            var list = new List<DiaPhuong>();
            cmd.Connection.Open();
            using (var reader = cmd.ExecuteReader())
            {
                if (!reader.HasRows) return list;

                // get ordinals once for performance
                int idxMaDP = GetOrdinalSafe(reader, "MaDP");
                int idxTenDP = GetOrdinalSafe(reader, "TenDP");
                int idxSoCa = GetOrdinalSafe(reader, "SoCaNhiemMoi");
                int idxMaTT = GetOrdinalSafe(reader, "MaTT");
                int idxTenTT = GetOrdinalSafe(reader, "TenTT");

                while (reader.Read())
                {
                    list.Add(new DiaPhuong
                    {
                        MaDP = idxMaDP >= 0 && !reader.IsDBNull(idxMaDP) ? reader.GetString(idxMaDP) : null,
                        TenDP = idxTenDP >= 0 && !reader.IsDBNull(idxTenDP) ? reader.GetString(idxTenDP) : null,
                        SoCaNhiemMoi = idxSoCa >= 0 && !reader.IsDBNull(idxSoCa) ? reader.GetInt32(idxSoCa) : 0,
                        MaTT = idxMaTT >= 0 && !reader.IsDBNull(idxMaTT) ? reader.GetInt32(idxMaTT) : 0,
                        TenTT = idxTenTT >= 0 && !reader.IsDBNull(idxTenTT) ? reader.GetString(idxTenTT) : null
                    });
                }
            }

            return list;
        }

        private static DiaPhuong Map(IDataRecord reader)
        {
            int idxMaDP = GetOrdinalSafe(reader, "MaDP");
            int idxTenDP = GetOrdinalSafe(reader, "TenDP");
            int idxSoCa = GetOrdinalSafe(reader, "SoCaNhiemMoi");
            int idxMaTT = GetOrdinalSafe(reader, "MaTT");
            int idxTenTT = GetOrdinalSafe(reader, "TenTT");

            return new DiaPhuong
            {
                MaDP = idxMaDP >= 0 && !reader.IsDBNull(idxMaDP) ? reader.GetString(idxMaDP) : null,
                TenDP = idxTenDP >= 0 && !reader.IsDBNull(idxTenDP) ? reader.GetString(idxTenDP) : null,
                SoCaNhiemMoi = idxSoCa >= 0 && !reader.IsDBNull(idxSoCa) ? reader.GetInt32(idxSoCa) : 0,
                MaTT = idxMaTT >= 0 && !reader.IsDBNull(idxMaTT) ? reader.GetInt32(idxMaTT) : 0,
                TenTT = idxTenTT >= 0 && !reader.IsDBNull(idxTenTT) ? reader.GetString(idxTenTT) : null
            };
        }

        private static int GetOrdinalSafe(IDataRecord reader, string name)
        {
            try
            {
                return reader.GetOrdinal(name);
            }
            catch (IndexOutOfRangeException)
            {
                return -1;
            }
        }
    }
}