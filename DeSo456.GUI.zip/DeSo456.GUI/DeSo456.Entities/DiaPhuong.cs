using System;

namespace DeSo456.Entities
{
    public class DiaPhuong
    {
        public string MaDP { get; set; }
        public string TenDP { get; set; }
        public int SoCaNhiemMoi { get; set; }
        public int MaTT { get; set; }
        public string TenTT { get; set; }
    }
}