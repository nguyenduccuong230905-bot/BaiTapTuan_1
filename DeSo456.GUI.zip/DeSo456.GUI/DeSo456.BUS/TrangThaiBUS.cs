﻿using DeSo456.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace DeSo456.BUS
{
    public class TrangThaiBUS
    {
        private readonly TrangThaiDAL dal = new TrangThaiDAL();
        public List<TrangThai> GetAll() => dal.GetAll();
    }
}