﻿using DeSo456.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeSo456.BUS
{
    public class DiaPhuongBUS
    {
        private readonly DiaPhuongDAL dal = new DiaPhuongDAL();

        public List<DiaPhuong> GetAll() => dal.GetAll();
        public bool Insert(DiaPhuong dp) => dal.Insert(dp);
        public bool Update(DiaPhuong dp) => dal.Update(dp);
        public DiaPhuong GetByMaDP(string maDP) => dal.GetByMaDP(maDP);
        public List<DiaPhuong> GetNguyCo() => dal.GetNguyCo();
        public List<DiaPhuong> GetAllSorted(bool ascending = false) => dal.GetAllSorted(ascending);
    }
}
