using System.Collections.Generic;

namespace DeSo456.GUI.Entities
{
    public class TrangThai
    {
        public TrangThai()
        {
            DiaPhuongs = new HashSet<DiaPhuong>();
        }

        public int MaTT { get; set; }
        public string TenTT { get; set; }
        public string GhiChu { get; set; }

        // Collection navigation required by EF mapping in Model1
        public virtual ICollection<DiaPhuong> DiaPhuongs { get; set; }
    }
}  