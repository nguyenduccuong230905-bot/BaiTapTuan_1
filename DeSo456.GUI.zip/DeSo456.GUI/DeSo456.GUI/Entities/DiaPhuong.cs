﻿namespace DeSo456.GUI.Entities
{
    public class DiaPhuong
    {
        public string MaDP { get; set; }
        public string TenDP { get; set; }
        public int SoCaNhiemMoi { get; set; }
        public int MaTT { get; set; }
        public string TenTT { get; set; }

        // Navigation property required by EF mapping in Model1
        public virtual TrangThai TrangThai { get; set; }
    }
}