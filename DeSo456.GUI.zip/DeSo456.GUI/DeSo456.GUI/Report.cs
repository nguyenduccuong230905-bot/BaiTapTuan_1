﻿using DeSo456.BUS;
using DeSo456.GUI.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DeSo456.GUI
{
    public partial class FrmReport : Form
    {
        private readonly DiaPhuongBUS _dpBUS = new DiaPhuongBUS();

        public FrmReport()
        {
            InitializeComponent();
        }

        private void FrmReport_Load(object sender, EventArgs e)
        {
            dgvReport.DataSource = _dpBUS.GetAll();
            if (dgvReport.Columns.Count > 0)
            {
                if (dgvReport.Columns.Contains("MaDP")) dgvReport.Columns["MaDP"].HeaderText = "MDP";
                if (dgvReport.Columns.Contains("TenDP")) dgvReport.Columns["TenDP"].HeaderText = "Tên ĐP";
                if (dgvReport.Columns.Contains("SoCaNhiemMoi")) dgvReport.Columns["SoCaNhiemMoi"].HeaderText = "Số ca nhiễm";
                if (dgvReport.Columns.Contains("TenTT")) dgvReport.Columns["TenTT"].HeaderText = "Trạng Thái";
            }
        }

        private void btnXem_Click(object sender, EventArgs e)
        {
            var sb = new StringBuilder();
            sb.AppendLine("=== BÁO CÁO TÌNH HÌNH DỊCH BỆNH ===");
            sb.AppendLine("MDP\tTên ĐP\tSố ca\tTrạng thái");

            foreach (DataGridViewRow row in dgvReport.Rows)
            {
                if (row.IsNewRow) continue;
                sb.AppendLine($"{row.Cells["MaDP"].Value}\t{row.Cells["TenDP"].Value}\t{row.Cells["SoCaNhiemMoi"].Value}\t{row.Cells["TenTT"].Value}");
            }

            MessageBox.Show(sb.ToString(), "Báo cáo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}