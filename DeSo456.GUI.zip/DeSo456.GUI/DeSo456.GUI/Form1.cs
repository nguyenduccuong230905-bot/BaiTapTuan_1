﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Windows.Forms;
using DeSo456.DAL;
using DeSo456.Entities;

namespace DeSo456.GUI
{
    public partial class Form1 : Form
    {
        private readonly DiaPhuongDAL _dpDAL;
        private readonly TrangThaiDAL _ttDAL;
        private bool _isSortedAscending;

        public Form1()
        {
            InitializeComponent();

            // Instantiate DAL classes but do not call DB here (keeps designer working)
            _dpDAL = new DiaPhuongDAL();
            _ttDAL = new TrangThaiDAL();

            Load += Form1_Load;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Prevent design-time execution which can break the WinForms designer
            if (LicenseManager.UsageMode == LicenseUsageMode.Designtime) return;

            LoadDiaPhuong();
            LoadTrangThai();
        }

        private void LoadDiaPhuong()
        {
            List<DiaPhuong> data;
            try
            {
                data = _dpDAL.GetAll();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading data: {ex.Message}", "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                data = new List<DiaPhuong>();
            }

            dgvDiaPhuong.DataSource = data;

            if (dgvDiaPhuong.Columns.Count > 0)
            {
                if (dgvDiaPhuong.Columns.Contains("MaDP")) dgvDiaPhuong.Columns["MaDP"].HeaderText = "MDP";
                if (dgvDiaPhuong.Columns.Contains("TenDP")) dgvDiaPhuong.Columns["TenDP"].HeaderText = "Tên ĐP";
                if (dgvDiaPhuong.Columns.Contains("SoCaNhiemMoi")) dgvDiaPhuong.Columns["SoCaNhiemMoi"].HeaderText = "Ca nhiễm";
                if (dgvDiaPhuong.Columns.Contains("TenTT")) dgvDiaPhuong.Columns["TenTT"].HeaderText = "Trạng Thái";
            }
        }

        private void LoadTrangThai()
        {
            List<TrangThai> list;
            try
            {
                list = _ttDAL.GetAll();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading statuses: {ex.Message}", "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                list = new List<TrangThai>();
            }

            cboTrangThai.DataSource = list;
            cboTrangThai.DisplayMember = "TenTT";
            cboTrangThai.ValueMember = "MaTT";
            if (cboTrangThai.Items.Count > 0) cboTrangThai.SelectedIndex = 0;
        }

        private void ClearInputs()
        {
            txtMaDP.Clear();
            txtTenDP.Clear();
            txtSoCa.Clear();
            if (cboTrangThai.Items.Count > 0) cboTrangThai.SelectedIndex = 0;
            txtMaDP.Focus();
        }

        private void mnuChucNang_Click(object sender, EventArgs e)
        {
            // No-op for top-level menu item
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            _isSortedAscending = !_isSortedAscending;
            var data = _dpDAL.GetAllSorted(_isSortedAscending);
            dgvDiaPhuong.DataSource = data;
            MessageBox.Show($"Đã sắp xếp {(_isSortedAscending ? "tăng dần" : "giảm dần")} theo số ca nhiễm.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void cácĐịaPhươngNhómNguyCơToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var data = _dpDAL.GetNguyCo();
            dgvDiaPhuong.DataSource = data;
            MessageBox.Show("Đã hiển thị các địa phương nhóm nguy cơ (không bình thường).", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void xuấtBáoCáoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var reportForm = new FrmReport(); // Ensure FrmReport exists
            reportForm.ShowDialog();
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.F1)
            {
                toolStripMenuItem1_Click(null, EventArgs.Empty);
                return true;
            }
            else if (keyData == Keys.F2)
            {
                cácĐịaPhươngNhómNguyCơToolStripMenuItem_Click(null, EventArgs.Empty);
                return true;
            }
            else if (keyData == (Keys.Control | Keys.R))
            {
                xuấtBáoCáoToolStripMenuItem_Click(null, EventArgs.Empty);
                return true;
            }

            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void dgvDiaPhuong_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            var row = dgvDiaPhuong.Rows[e.RowIndex];
            txtMaDP.Text = row.Cells["MaDP"].Value?.ToString() ?? string.Empty;
            txtTenDP.Text = row.Cells["TenDP"].Value?.ToString() ?? string.Empty;
            txtSoCa.Text = row.Cells["SoCaNhiemMoi"].Value?.ToString() ?? string.Empty;
            if (row.Cells["MaTT"].Value != null)
            {
                cboTrangThai.SelectedValue = row.Cells["MaTT"].Value;
            }
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtMaDP.Text) || string.IsNullOrWhiteSpace(txtTenDP.Text) || string.IsNullOrWhiteSpace(txtSoCa.Text))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (txtMaDP.Text.Length != 3)
            {
                MessageBox.Show("Mã địa phương phải là 3 ký tự!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!int.TryParse(txtSoCa.Text, out int soCa) || soCa < 0)
            {
                MessageBox.Show("Số ca nhiễm mới phải là số nguyên không âm!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var dp = new DiaPhuong
            {
                MaDP = txtMaDP.Text.Trim(),
                        TenDP = txtTenDP.Text.Trim(),
                SoCaNhiemMoi = soCa,
                MaTT = (int)(cboTrangThai.SelectedValue ?? 0)
            };

            if (_dpDAL.Insert(dp))
            {
                MessageBox.Show("Thêm mới thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadDiaPhuong();
                ClearInputs();
            }
            else
            {
                MessageBox.Show("Thêm thất bại! Mã địa phương có thể đã tồn tại.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCapNhat_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtMaDP.Text))
            {
                MessageBox.Show("Vui lòng chọn một địa phương để cập nhật!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var currentDP = _dpDAL.GetByMaDP(txtMaDP.Text);
            if (currentDP == null)
            {
                MessageBox.Show("Không tìm thấy thông tin địa phương!", "Lá»—i", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!int.TryParse(txtSoCa.Text, out int soCa) || soCa < 0)
            {
                MessageBox.Show("Số ca nhiễm mới phải là số nguyên không âm!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var newMaTT = (int)(cboTrangThai.SelectedValue ?? 0);

            if (currentDP.MaTT != newMaTT)
            {
                var oldTT = _ttDAL.GetAll().Find(t => t.MaTT == currentDP.MaTT)?.TenTT ?? "Unknown";
                var newTT = _ttDAL.GetAll().Find(t => t.MaTT == newMaTT)?.TenTT ?? "Unknown";

                var result = MessageBox.Show(
                    $"Địa phương có sự thay đổi từ '{oldTT}' -> '{newTT}'? Bạn có muốn tiếp tục?",
                    "Cảnh báo",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Warning);

                if (result == DialogResult.No) return;
            }

            currentDP.TenDP = txtTenDP.Text.Trim();
            currentDP.SoCaNhiemMoi = soCa;
            currentDP.MaTT = newMaTT;

            if (_dpDAL.Update(currentDP))
            {
                MessageBox.Show("Cập nhật thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadDiaPhuong();
                ClearInputs();
            }
            else
            {
                MessageBox.Show("Cập nhật thất bại!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}