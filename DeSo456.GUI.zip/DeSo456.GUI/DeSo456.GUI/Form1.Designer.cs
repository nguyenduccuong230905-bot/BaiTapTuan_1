﻿namespace DeSo456.GUI
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem mnuChucNang;
        private System.Windows.Forms.GroupBox grpThongTin;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblMaDP;
        private System.Windows.Forms.Label lblTenDP;
        private System.Windows.Forms.Label lblSoCa;
        private System.Windows.Forms.Label lblTrangThai;
        private System.Windows.Forms.TextBox txtMaDP;
        private System.Windows.Forms.TextBox txtTenDP;
        private System.Windows.Forms.TextBox txtSoCa;
        private System.Windows.Forms.ComboBox cboTrangThai;
        private System.Windows.Forms.Button btnThem;
        private System.Windows.Forms.Button btnCapNhat;
        private System.Windows.Forms.DataGridView dgvDiaPhuong;
        private System.Windows.Forms.DataGridViewTextBoxColumn colMaDP;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTenDP;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSoCa;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTrangThai;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.mnuChucNang = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.cácĐịaPhươngNhómNguyCơToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.xuấtBáoCáoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.grpThongTin = new System.Windows.Forms.GroupBox();
            this.lblMaDP = new System.Windows.Forms.Label();
            this.txtMaDP = new System.Windows.Forms.TextBox();
            this.lblTenDP = new System.Windows.Forms.Label();
            this.txtTenDP = new System.Windows.Forms.TextBox();
            this.lblSoCa = new System.Windows.Forms.Label();
            this.txtSoCa = new System.Windows.Forms.TextBox();
            this.lblTrangThai = new System.Windows.Forms.Label();
            this.cboTrangThai = new System.Windows.Forms.ComboBox();
            this.btnThem = new System.Windows.Forms.Button();
            this.btnCapNhat = new System.Windows.Forms.Button();
            this.lblTitle = new System.Windows.Forms.Label();
            this.dgvDiaPhuong = new System.Windows.Forms.DataGridView();
            this.colMaDP = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTenDP = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSoCa = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTrangThai = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.menuStrip1.SuspendLayout();
            this.grpThongTin.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDiaPhuong)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuChucNang});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(900, 28);
            this.menuStrip1.TabIndex = 3;
            // 
            // mnuChucNang
            // 
            this.mnuChucNang.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.cácĐịaPhươngNhómNguyCơToolStripMenuItem,
            this.toolStripSeparator1,
            this.xuấtBáoCáoToolStripMenuItem});
            this.mnuChucNang.Name = "mnuChucNang";
            this.mnuChucNang.Size = new System.Drawing.Size(93, 24);
            this.mnuChucNang.Text = "Chức năng";
            this.mnuChucNang.Click += new System.EventHandler(this.mnuChucNang_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(346, 26);
            this.toolStripMenuItem1.Text = "Sắp xếp theo số ca nhiễm             F1";
            // 
            // cácĐịaPhươngNhómNguyCơToolStripMenuItem
            // 
            this.cácĐịaPhươngNhómNguyCơToolStripMenuItem.Name = "cácĐịaPhươngNhómNguyCơToolStripMenuItem";
            this.cácĐịaPhươngNhómNguyCơToolStripMenuItem.Size = new System.Drawing.Size(346, 26);
            this.cácĐịaPhươngNhómNguyCơToolStripMenuItem.Text = "Các địa phương nhóm nguy cơ         F2";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(343, 6);
            // 
            // xuấtBáoCáoToolStripMenuItem
            // 
            this.xuấtBáoCáoToolStripMenuItem.Name = "xuấtBáoCáoToolStripMenuItem";
            this.xuấtBáoCáoToolStripMenuItem.Size = new System.Drawing.Size(346, 26);
            this.xuấtBáoCáoToolStripMenuItem.Text = "xuất báo cáo        Ctrl+R";
            // 
            // grpThongTin
            // 
            this.grpThongTin.Controls.Add(this.lblMaDP);
            this.grpThongTin.Controls.Add(this.txtMaDP);
            this.grpThongTin.Controls.Add(this.lblTenDP);
            this.grpThongTin.Controls.Add(this.txtTenDP);
            this.grpThongTin.Controls.Add(this.lblSoCa);
            this.grpThongTin.Controls.Add(this.txtSoCa);
            this.grpThongTin.Controls.Add(this.lblTrangThai);
            this.grpThongTin.Controls.Add(this.cboTrangThai);
            this.grpThongTin.Controls.Add(this.btnThem);
            this.grpThongTin.Controls.Add(this.btnCapNhat);
            this.grpThongTin.Location = new System.Drawing.Point(12, 90);
            this.grpThongTin.Name = "grpThongTin";
            this.grpThongTin.Size = new System.Drawing.Size(280, 240);
            this.grpThongTin.TabIndex = 1;
            this.grpThongTin.TabStop = false;
            this.grpThongTin.Text = "Thông tin địa phương";
            // 
            // lblMaDP
            // 
            this.lblMaDP.Location = new System.Drawing.Point(10, 30);
            this.lblMaDP.Name = "lblMaDP";
            this.lblMaDP.Size = new System.Drawing.Size(100, 23);
            this.lblMaDP.TabIndex = 0;
            this.lblMaDP.Text = "Mã Địa Phương";
            // 
            // txtMaDP
            // 
            this.txtMaDP.Location = new System.Drawing.Point(120, 27);
            this.txtMaDP.Name = "txtMaDP";
            this.txtMaDP.Size = new System.Drawing.Size(130, 22);
            this.txtMaDP.TabIndex = 1;
            // 
            // lblTenDP
            // 
            this.lblTenDP.Location = new System.Drawing.Point(10, 65);
            this.lblTenDP.Name = "lblTenDP";
            this.lblTenDP.Size = new System.Drawing.Size(100, 23);
            this.lblTenDP.TabIndex = 2;
            this.lblTenDP.Text = "Tên ĐP";
            // 
            // txtTenDP
            // 
            this.txtTenDP.Location = new System.Drawing.Point(120, 62);
            this.txtTenDP.Name = "txtTenDP";
            this.txtTenDP.Size = new System.Drawing.Size(130, 22);
            this.txtTenDP.TabIndex = 3;
            // 
            // lblSoCa
            // 
            this.lblSoCa.Location = new System.Drawing.Point(10, 100);
            this.lblSoCa.Name = "lblSoCa";
            this.lblSoCa.Size = new System.Drawing.Size(100, 23);
            this.lblSoCa.TabIndex = 4;
            this.lblSoCa.Text = "Số Ca mới";
            // 
            // txtSoCa
            // 
            this.txtSoCa.Location = new System.Drawing.Point(120, 97);
            this.txtSoCa.Name = "txtSoCa";
            this.txtSoCa.Size = new System.Drawing.Size(130, 22);
            this.txtSoCa.TabIndex = 5;
            // 
            // lblTrangThai
            // 
            this.lblTrangThai.Location = new System.Drawing.Point(10, 135);
            this.lblTrangThai.Name = "lblTrangThai";
            this.lblTrangThai.Size = new System.Drawing.Size(100, 23);
            this.lblTrangThai.TabIndex = 6;
            this.lblTrangThai.Text = "Trạng Thái";
            // 
            // cboTrangThai
            // 
            this.cboTrangThai.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboTrangThai.Location = new System.Drawing.Point(120, 132);
            this.cboTrangThai.Name = "cboTrangThai";
            this.cboTrangThai.Size = new System.Drawing.Size(130, 24);
            this.cboTrangThai.TabIndex = 7;
            // 
            // btnThem
            // 
            this.btnThem.Location = new System.Drawing.Point(40, 180);
            this.btnThem.Name = "btnThem";
            this.btnThem.Size = new System.Drawing.Size(75, 23);
            this.btnThem.TabIndex = 8;
            this.btnThem.Text = "Thêm";
            this.btnThem.Click += new System.EventHandler(this.btnThem_Click);
            // 
            // btnCapNhat
            // 
            this.btnCapNhat.Location = new System.Drawing.Point(140, 180);
            this.btnCapNhat.Name = "btnCapNhat";
            this.btnCapNhat.Size = new System.Drawing.Size(75, 23);
            this.btnCapNhat.TabIndex = 9;
            this.btnCapNhat.Text = "Cập nhật";
            this.btnCapNhat.Click += new System.EventHandler(this.btnCapNhat_Click);
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold);
            this.lblTitle.ForeColor = System.Drawing.Color.Blue;
            this.lblTitle.Location = new System.Drawing.Point(330, 40);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(317, 37);
            this.lblTitle.TabIndex = 2;
            this.lblTitle.Text = "Tình hình dịch Covid 19";
            // 
            // dgvDiaPhuong
            // 
            this.dgvDiaPhuong.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvDiaPhuong.ColumnHeadersHeight = 29;
            this.dgvDiaPhuong.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colMaDP,
            this.colTenDP,
            this.colSoCa,
            this.colTrangThai});
            this.dgvDiaPhuong.Location = new System.Drawing.Point(310, 90);
            this.dgvDiaPhuong.Name = "dgvDiaPhuong";
            this.dgvDiaPhuong.ReadOnly = true;
            this.dgvDiaPhuong.RowHeadersWidth = 51;
            this.dgvDiaPhuong.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDiaPhuong.Size = new System.Drawing.Size(560, 300);
            this.dgvDiaPhuong.TabIndex = 0;
            this.dgvDiaPhuong.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvDiaPhuong_CellContentClick);
            // 
            // colMaDP
            // 
            this.colMaDP.DataPropertyName = "MaDP";
            this.colMaDP.HeaderText = "MDP";
            this.colMaDP.MinimumWidth = 6;
            this.colMaDP.Name = "colMaDP";
            this.colMaDP.ReadOnly = true;
            // 
            // colTenDP
            // 
            this.colTenDP.DataPropertyName = "TenDP";
            this.colTenDP.HeaderText = "Tên ĐP";
            this.colTenDP.MinimumWidth = 6;
            this.colTenDP.Name = "colTenDP";
            this.colTenDP.ReadOnly = true;
            // 
            // colSoCa
            // 
            this.colSoCa.DataPropertyName = "SoCaNhiemMoi";
            this.colSoCa.HeaderText = "Ca nhiễm";
            this.colSoCa.MinimumWidth = 6;
            this.colSoCa.Name = "colSoCa";
            this.colSoCa.ReadOnly = true;
            // 
            // colTrangThai
            // 
            this.colTrangThai.DataPropertyName = "TenTT";
            this.colTrangThai.HeaderText = "Trạng Thái";
            this.colTrangThai.MinimumWidth = 6;
            this.colTrangThai.Name = "colTrangThai";
            this.colTrangThai.ReadOnly = true;
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(900, 420);
            this.Controls.Add(this.dgvDiaPhuong);
            this.Controls.Add(this.grpThongTin);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Thông tin địa phương";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.grpThongTin.ResumeLayout(false);
            this.grpThongTin.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDiaPhuong)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion

        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem cácĐịaPhươngNhómNguyCơToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem xuấtBáoCáoToolStripMenuItem;
    }
}